/// Support for doing something awesome.
///
/// More dartdocs go here.
library adaptive_number;

export 'src/number.dart';
