import 'package:adaptive_number/src/number.dart';

Number createNumber(int val) => throw UnsupportedError(
    'Cannot create a Number without package dart.library.io or dart.library.html being available');
