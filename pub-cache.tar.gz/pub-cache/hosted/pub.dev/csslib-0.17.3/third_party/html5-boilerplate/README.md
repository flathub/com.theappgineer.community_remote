This folder contains sample css files from the open-source project
https://github.com/h5bp/html5-boilerplate.

This code was included under the terms in the `LICENSE.txt` file.