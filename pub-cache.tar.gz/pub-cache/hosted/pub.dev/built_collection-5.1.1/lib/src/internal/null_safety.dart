/// Whether runtime sound mode is enabled.
final bool isSoundMode = <int?>[] is! List<int>;
