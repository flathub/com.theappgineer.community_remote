# Built Collection Benchmarks

This package contains simple microbenchmarks for `built_collection`.

To run for the VM:

```bash
dart bin/main.dart
```

To run for web:

```
pub run build_runner serve web
<navigate browser to localhost:8080; results appear in the console>
```

In the output, higher values are better.
