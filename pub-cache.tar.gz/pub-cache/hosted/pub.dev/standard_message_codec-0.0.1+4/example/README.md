# example_standard_message_codec

A sample app for demonstrating the StandardMessageCodec
